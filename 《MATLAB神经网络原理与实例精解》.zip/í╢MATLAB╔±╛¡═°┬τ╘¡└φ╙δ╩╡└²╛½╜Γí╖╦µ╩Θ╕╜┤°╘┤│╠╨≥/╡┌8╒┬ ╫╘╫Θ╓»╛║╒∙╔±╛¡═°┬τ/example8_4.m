% example8_4.m

pos = tritop(8,5);
net = selforgmap([8 5],'topologyFcn','tritop');
plotsomtop(net)
web -broswer http://www.ilovematlab.cn/forum-222-1.html