% example6_2.m

x=-4:.1:4;
y=tansig(x);			% Tag-Sigmoid����
plot(x,y,'^-r')
title('Tan-sig ����')
xlabel('x')
ylabel('y')
grid on
% web -broswer http://www.ilovematlab.cn/forum-222-1.html