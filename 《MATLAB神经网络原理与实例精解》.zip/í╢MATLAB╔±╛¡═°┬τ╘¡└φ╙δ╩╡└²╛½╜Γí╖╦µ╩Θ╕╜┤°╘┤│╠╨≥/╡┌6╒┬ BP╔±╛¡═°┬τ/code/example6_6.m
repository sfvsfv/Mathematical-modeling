% example6_6.m
f1=feedforwardnet([3,5]);
f2=cascadeforwardnet([3,5]);
view(f1)
view(f2)
web -broswer http://www.ilovematlab.cn/forum-222-1.html