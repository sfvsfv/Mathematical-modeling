% example5_3.m
x=-5:5;
y=purelin(x)		% y����x

% y =
% 
%     -5    -4    -3    -2    -1     0     1     2     3     4     5
web -broswer http://www.ilovematlab.cn/forum-222-1.html